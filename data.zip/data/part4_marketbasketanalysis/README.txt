source: https://www.kaggle.com/jihyeseo/online-retail-data-set-from-uci-ml-repo

Les données fournies sont un sous-ensemble de l'ensemble OnlineRetail.csv