source: https://www.kaggle.com/datatattle/covid-19-nlp-text-classification

Les données fournies sont un sous-ensemble de l'ensemble Corona_NLP_test.csv