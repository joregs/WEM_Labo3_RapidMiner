source: https://www.kaggle.com/vikassingh1996/news-clickbait-dataset

Les données fournies sont un sous-ensemble de l'ensemble train1.csv

