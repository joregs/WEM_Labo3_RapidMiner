source: https://grouplens.org/datasets/movielens/

Les données fournies font partie de l'ensemble Small MovieLens Dataset (ml-latest-small.zip) recommandé pour l'éducation et le développement