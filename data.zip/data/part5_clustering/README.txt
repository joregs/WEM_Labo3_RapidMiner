source: https://www.kaggle.com/lava18/google-play-store-apps

Les données fournies sont un sous-ensemble de l'ensemble googleplaystore.csv
